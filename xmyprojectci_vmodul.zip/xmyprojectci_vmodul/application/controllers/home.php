<?php 
/**
 * 
 */
class Home extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
		
	}

	function index()
	{
		$page = $this->input->GET('page');
		switch ($page) {
			case 'mhs':
				# code...
				$this->mhs();
				break;
			case 'mhs_add_save':
				# code...
				$this->mhs_add_save();
				break;
			case 'mhs_upd':
				# code...
				$this->mhs_upd();
				break;
			case 'mhs_upd_save':
				# code...
				$this->mhs_upd_save();
				break;
			case 'mhs_del':
				# code...
				$this->mhs_del();
				break;
			case 'mk':
				# code...
				$this->mk();
				break;
			case 'mk_add_save':
				# code...
				$this->mk_add_save();
				break;
			case 'mk_upd':
				# code...
				$this->mk_upd();
				break;
			case 'mk_upd_save':
				# code...
				$this->mk_upd_save();
				break;
			case 'mk_del':
				# code...
				$this->mk_del();
				break;
			case 'nilai':
				# code...
				$this->nilai();
				break;
			case 'nilai_add_save':
				# code...
				$this->nilai_add_save();
				break;
			case 'nilai_upd':
				# code...
				$this->nilai_upd();
				break;
			case 'nilai_upd_save':
				# code...
				$this->nilai_upd_save();
				break;
			case 'nilai_del':
				# code...
				$this->nilai_del();
			default:
				# code...
				$this->load->view('index');
				break;
		}
	}

	function mhs()
	{
		$this->load->model('students');
		$data['qstudents'] = $this->students->get_allstudents();
		$this->load->view('index',$data);
	}

	function mhs_add_save()
	{
		#Get form variables
		$id_num = addslashes($this->input->POST('id_num'));
		$first_name = addslashes($this->input->POST('first_name'));
		$last_name = addslashes($this->input->POST('last_name'));
		$address = addslashes($this->input->POST('address'));
		$phone_num = addslashes($this->input->POST('phone_num'));

		$this->load->model('students');
		$data = array(
			'id_num' => $id_num,
			'first_name' => $first_name,
			'last_name' => $last_name,
			'address' => $address,
			'phone_num' => $phone_num
		);
		$this->students->ins($data);
		redirect(base_url('index.php?page=mhs'));
	}

	function mhs_upd()
	{
		$id = $this->input->GET('id');
		$this->load->model('students');
		$data['qstudents'] = $this->students->get_byid($id);
		$this->load->view('index',$data);
	}

	function mhs_upd_save()
	{
		#Get form variables
		$id = $this->input->GET('id');
		$id_num = addslashes($this->input->POST('id_num'));
		$first_name = addslashes($this->input->POST('first_name'));
		$last_name = addslashes($this->input->POST('last_name'));
		$address = addslashes($this->input->POST('address'));
		$phone_num = addslashes($this->input->POST('phone_num'));

		$this->load->model('students');
		$data = array(
			'id_num' => $id_num,
			'first_name' => $first_name,
			'last_name' => $last_name,
			'address' => $address,
			'phone_num' => $phone_num
		);
		$this->students->upd($id,$data);
		redirect(base_url('index.php?page=mhs'));
	}

	function mhs_del()
	{
		$id = $this->input->GET('id');
		$this->load->model('students');
		$this->students->del($id);
		redirect(base_url('index.php?page=mhs'));
	}

	function mk()
	{
		$this->load->model('mk');
		$data['qmk'] = $this->mk->get_allmk();
		$this->load->view('index',$data);
	}

	function mk_add_save()
	{
		#Get form variables
		$kode_mk = addslashes($this->input->POST('kode_mk'));
		$nama = addslashes($this->input->POST('nama'));
		$jml_sks = addslashes($this->input->POST('jml_sks'));
		
		$this->load->model('mk');
		$data = array(
			'kode_mk' => $kode_mk,
			'nama' => $nama,
			'jml_sks' => $jml_sks
		);
		$this->mk->ins($data);
		redirect(base_url('index.php?page=mk'));
	}

	function mk_upd()
	{
		$id = $this->input->GET('id');
		$this->load->model('mk');
		$data['qmk'] = $this->mk->get_byid($id);
		$this->load->view('index',$data);
	}

	function mk_upd_save()
	{
		#Get form variables
		$id = $this->input->GET('id');
		$kode_mk = addslashes($this->input->POST('kode_mk'));
		$nama = addslashes($this->input->POST('nama'));
		$jml_sks = addslashes($this->input->POST('jml_sks'));

		$this->load->model('mk');
		$data = array(
			'kode_mk' => $kode_mk,
			'nama' => $nama,
			'jml_sks' => $jml_sks
		);
		$this->mk->upd($id,$data);
		redirect(base_url('index.php?page=mk'));
	}

	function mk_del()
	{
		$id = $this->input->GET('id');
		$this->load->model('mk');
		$this->mk->del($id);
		redirect(base_url('index.php?page=mk'));
	}
}
 ?>