<?php 
/**
 * 
 */
class Mahasiswa extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}

	function index()
	{
		# code...
		$page = $this->input->GET('page');
		switch ($page) {
			case 'mhs_add_save':
				# code...
				$this->mhs_add_save();
				break;
			case 'mhs_upd':
				# code...
				$this->mhs_upd();
				break;
			case 'mhs_upd_save':
				# code...
				$this->mhs_upd_save();
				break;
			case 'mhs_del':
				# code...
				$this->mhs_del();
				break;
			default:
				# code...
				//$this->load->view('index');
			$this->mhs();
				break;
		}

	}

	function mhs()
	{
		$this->load->model('students');
		$data['qstudents'] = $this->students->get_allstudents();
		$this->load->view('index_mhs',$data);
	}

	function mhs_add_save()
	{
		#Get form variables
		$id_num = addslashes($this->input->POST('id_num'));
		$first_name = addslashes($this->input->POST('first_name'));
		$last_name = addslashes($this->input->POST('last_name'));
		$address = addslashes($this->input->POST('address'));
		$phone_num = addslashes($this->input->POST('phone_num'));

		$this->load->model('students');
		$data = array(
			'id_num' => $id_num,
			'first_name' => $first_name,
			'last_name' => $last_name,
			'address' => $address,
			'phone_num' => $phone_num
		);
		$this->students->ins($data);
		redirect(base_url('mahasiswa'));
	}

	function mhs_upd()
	{
		$id = $this->input->GET('id');
		$this->load->model('students');
		$data['qstudents'] = $this->students->get_byid($id);
		$this->load->view('index_mhs',$data);
	}

	function mhs_upd_save()
	{
		#Get form variables
		$id = $this->input->GET('id');
		$id_num = addslashes($this->input->POST('id_num'));
		$first_name = addslashes($this->input->POST('first_name'));
		$last_name = addslashes($this->input->POST('last_name'));
		$address = addslashes($this->input->POST('address'));
		$phone_num = addslashes($this->input->POST('phone_num'));

		$this->load->model('students');
		$data = array(
			'id_num' => $id_num,
			'first_name' => $first_name,
			'last_name' => $last_name,
			'address' => $address,
			'phone_num' => $phone_num
		);
		$this->students->upd($id,$data);
		redirect(base_url('mahasiswa'));
	}

	function mhs_del()
	{
		$id = $this->input->GET('id');
		$this->load->model('students');
		$this->students->del($id);
		redirect(base_url('mahasiswa'));
	}

}
 ?>