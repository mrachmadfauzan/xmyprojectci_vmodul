<?php 
/**
 * 
 */
class Matakuliah extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
		
	}

	function index()
	{
		$page = $this->input->GET('page');
		switch ($page) {
			case 'mk_add_save':
				# code...
				$this->mk_add_save();
				break;
			case 'mk_upd':
				# code...
				$this->mk_upd();
				break;
			case 'mk_upd_save':
				# code...
				$this->mk_upd_save();
				break;
			case 'mk_del':
				# code...
				$this->mk_del();
				break;
			default:
				# code...
				$this->mk();
				break;
		}
	}

	function mk()
	{
		$this->load->model('mk');
		$data['qmk'] = $this->mk->get_allmk();
		$this->load->view('index_mk',$data);
	}

	function mk_add_save()
	{
		#Get form variables
		$kode_mk = addslashes($this->input->POST('kode_mk'));
		$nama = addslashes($this->input->POST('nama'));
		$jml_sks = addslashes($this->input->POST('jml_sks'));
		
		$this->load->model('mk');
		$data = array(
			'kode_mk' => $kode_mk,
			'nama' => $nama,
			'jml_sks' => $jml_sks
		);
		$this->mk->ins($data);
		redirect(base_url('matakuliah'));
	}

	function mk_upd()
	{
		$id = $this->input->GET('id');
		$this->load->model('mk');
		$data['qmk'] = $this->mk->get_byid($id);
		$this->load->view('index_mk',$data);
	}

	function mk_upd_save()
	{
		#Get form variables
		$id = $this->input->GET('id');
		$kode_mk = addslashes($this->input->POST('kode_mk'));
		$nama = addslashes($this->input->POST('nama'));
		$jml_sks = addslashes($this->input->POST('jml_sks'));

		$this->load->model('mk');
		$data = array(
			'kode_mk' => $kode_mk,
			'nama' => $nama,
			'jml_sks' => $jml_sks
		);
		$this->mk->upd($id,$data);
		redirect(base_url('matakuliah'));
	}

	function mk_del()
	{
		$id = $this->input->GET('id');
		$this->load->model('mk');
		$this->mk->del($id);
		redirect(base_url('matakuliah'));
	}
}
 ?>