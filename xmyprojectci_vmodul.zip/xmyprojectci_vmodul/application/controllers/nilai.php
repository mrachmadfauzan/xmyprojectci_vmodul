<?php 
/**
 * 
 */
class Nilai extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
		
	}

	function index()
	{
		$page = $this->input->GET('page');
		switch ($page) {
			case 'nilai_add':
				# code...
				$this->nilai_add();
				break;
			case 'nilai_add_save':
				# code...
				$this->nilai_add_save();
				break;
			case 'nilai_upd':
				# code...
				$this->nilai_upd();
				break;
			case 'nilai_upd_save':
				# code...
				$this->nilai_upd_save();
				break;
			case 'nilai_del':
				# code...
				$this->nilai_del();
				break;
			default:
				# code...
				$this->nilai();
				break;
		}
	}

	function nilai()
	{
		$this->load->model('mnilai');
		$data['qnilai'] = $this->mnilai->get_allnilai();
		$this->load->view('index_nilai',$data);
	}

	function nilai_add()
	{
		$this->load->model('students');
		$this->load->model('mk');
		$data['qstudents'] = $this->students->get_allstudents();
		$data['qmk'] = $this->mk->get_allmk();
		$this->load->view('index_nilai',$data);
	}

	function nilai_add_save()
	{
		#Get form variables
		$stu_id = addslashes($this->input->POST('stu_id'));
		$mk_id = addslashes($this->input->POST('mk_id'));
		$nilai = addslashes($this->input->POST('nilai'));
		
		$this->load->model('mnilai');
		$data = array(
			'stu_id' => $stu_id,
			'mk_id' => $mk_id,
			'nilai' => $nilai
		);
		$this->mnilai->ins($data);
		redirect(base_url('nilai'));
	}

	function nilai_upd()
	{
		$id = $this->input->GET('id');
		$this->load->model('mnilai');
		$this->load->model('students');
		$this->load->model('mk');
		$data['qnilai'] = $this->mnilai->get_byid($id);
		$data['qstudents'] = $this->students->get_allstudents();
		$data['qmk'] = $this->mk->get_allmk();
		$this->load->view('index_nilai',$data);
	}

	function nilai_upd_save()
	{
		#Get form variables
		$nilai_id = $this->input->GET('id');
		$stu_id = addslashes($this->input->POST('stu_id'));
		$mk_id = addslashes($this->input->POST('mk_id'));
		$nilai = addslashes($this->input->POST('nilai'));

		$this->load->model('mnilai');
		$data = array(
			'stu_id' => $stu_id,
			'mk_id' => $mk_id,
			'nilai' => $nilai
		);
		$this->mnilai->upd($nilai_id,$data);
		redirect(base_url('nilai'));
	}

	function nilai_del()
	{
		$nilai_id = $this->input->GET('id');
		$this->load->model('mnilai');
		$this->mnilai->del($nilai_id);
		redirect(base_url('nilai'));
	}
}
 ?>