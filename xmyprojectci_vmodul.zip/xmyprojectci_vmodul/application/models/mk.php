<?php 
/**
 * 
 */
class Mk extends CI_Model
{
	var $tabel = 'mk';
	function __construct()
	{
		# code...
		parent::__construct();
	}
	function get_allmk()
	{
		$this->db->from($this->tabel);
		$query = $this->db->get();

		# Any data?
		if ($query->num_rows() > 0) {
			# code...
			return $query->result();
		}
	}
	function ins($data)
	{
		$this->db->insert($this->tabel,$data);
		return TRUE;
	}
	function get_byid($id)
	{
		$this->db->from($this->tabel);
		$this->db->where('mk_id',$id);

		$query = $this->db->get();

		# Any data?
		if ($query->num_rows() > 0) {
			# code...
			return $query->result();
		}
	}
	function upd($id,$data)
	{
		$this->db->where('mk_id',$id);
		$this->db->update($this->tabel,$data);

		return TRUE;
	}
	function del($id)
	{
		$this->db->where('mk_id',$id);
		$this->db->delete($this->tabel);
		if ($this->db->affected_rows() == 1) {
			# code...
			return TRUE;
		}
		return FALSE;
	}
}
 ?>