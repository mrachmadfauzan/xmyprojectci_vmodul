<?php 
/**
 * 
 */
class Mnilai extends CI_Model
{
	var $tabel = 'nilai';
	function __construct()
	{
		# code...
		parent::__construct();
	}
	function get_allnilai()
	{
		//$this->db->from($this->tabel);
		$this->db->select('*')
     		->from($this->tabel)
			->join('students', 'nilai.stu_id = students.stu_id') 
			->join('mk', 'nilai.mk_id = mk.mk_id');
		$query = $this->db->get();

		# Any data?
		if ($query->num_rows() > 0) {
			# code...
			return $query->result();
		}
	}
	function ins($data)
	{
		$this->db->insert($this->tabel,$data);
		return TRUE;
	}
	function get_byid($id)
	{
		$this->db->from($this->tabel);
		$this->db->where('nilai_id',$id);

		$query = $this->db->get();

		# Any data?
		if ($query->num_rows() > 0) {
			# code...
			return $query->result();
		}
	}
	function upd($id,$data)
	{
		$this->db->where('nilai_id',$id);
		$this->db->update($this->tabel,$data);

		return TRUE;
	}
	function del($id)
	{
		$this->db->where('nilai_id',$id);
		$this->db->delete($this->tabel);
		if ($this->db->affected_rows() == 1) {
			# code...
			return TRUE;
		}
		return FALSE;
	}
}
 ?>