    </main>
    
	  <footer class="footer">
      <div class="container">
        <span class="text-muted">&copy 2019 Achmad Fauzan</span>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <script src="assets/css/bootstrap.min.js"></script>
    <script src="assets/js/jquery-3.3.1.min.js"></script>
  </body>
</html>