<?php 
include "header.php";

$queries = array();
parse_str($_SERVER['QUERY_STRING'], $queries);

error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
switch ($queries['page']) {
	case 'mhs_add':
		# code...
		include 'mhs/create.php';
		break;
	case 'mhs_upd':
		# code...
		include 'mhs/update.php';
		break;
	default:
		# code...
		include 'mhs/mhs_index.php';
		break;
}

include "footer.php";
 ?>