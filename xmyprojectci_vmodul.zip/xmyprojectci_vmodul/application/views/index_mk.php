<?php 
include "header.php";

$queries = array();
parse_str($_SERVER['QUERY_STRING'], $queries);

error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
switch ($queries['page']) {
	case 'mk_add':
		# code...
		include 'mk/create.php';
		break;
	case 'mk_upd':
		# code...
		include 'mk/update.php';
		break;
	default:
		# code...
		include 'mk/mk_index.php';
		break;
}

include "footer.php";
 ?>