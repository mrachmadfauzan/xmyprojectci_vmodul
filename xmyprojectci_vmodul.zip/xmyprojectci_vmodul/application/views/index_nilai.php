<?php 
include "header.php";

$queries = array();
parse_str($_SERVER['QUERY_STRING'], $queries);

error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
switch ($queries['page']) {
	case 'nilai_add':
		# code...
		include 'nilai/create.php';
		break;
	case 'nilai_upd':
		# code...
		include 'nilai/update.php';
		break;
	default:
		# code...
		include 'nilai/nilai_index.php';
		break;
}

include "footer.php";
 ?>