
	<div class="container">
		<h1>Student List</h1>
		<table class="table table-striped">
			<thead>
				<tr>
					<th>Number</th>
					<th>ID Number</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Address</th>
					<th>Phone Number</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					if (empty($qstudents)) {
						echo "<tr>";
						echo "<td colspan='7'>-</td>";
						echo "</tr>";
					} else {
						$num = 0;
					    // output data of each row
						foreach ($qstudents as $row) {
							# code...
					    	$num++;
					    	echo "<tr>";
					    	echo "<td>$num</td>";
					    	echo "<td>$row->id_num</td>";
					    	echo "<td>$row->first_name</td>";
					    	echo "<td>$row->last_name</td>";
					    	echo "<td>$row->address</td>";
					    	echo "<td>$row->phone_num</td>";
					    	echo "<td><a href='?page=mhs_upd&id=$row->stu_id'>Edit</a> | <a href='?page=mhs_del&id=$row->stu_id'>Delete</a></td>";
					    	echo "</tr>";
					    }
					} 
				?>
			</tbody>
		</table>
		<p><a href="?page=mhs_add">Add</a></p>
	</div>
