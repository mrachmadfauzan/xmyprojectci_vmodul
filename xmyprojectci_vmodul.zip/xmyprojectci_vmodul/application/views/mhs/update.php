
	<div class="container">
		<h1>Student | Update</h1>
		<?php 
			if (empty($qstudents)) {
				# code...

			} else {
				// output data of each row
				foreach ($qstudents as $row) {
					# code...
		?>
		<form action="?page=mhs_upd_save&id=<?=$row->stu_id?>" method="POST">
			<div class="form-group">
				<label for="id_num">ID Number:</label>
				<input type="text" class="form-control" id="id_num" name="id_num" required value="<?=$row->id_num?>">
			</div>
			<div class="form-group">
				<label for="first_name">First Name:</label>
				<input type="text" class="form-control" id="first_name" name="first_name" required value="<?=$row->first_name?>">
			</div>
			<div class="form-group">
				<label for="last_name">Last Name:</label>
				<input type="text" class="form-control" id="last_name" name="last_name" value="<?=$row->last_name?>">
			</div>
			<div class="form-group">
				<label for="address">Address Name:</label>
				<input type="text" class="form-control" id="address" name="address" value="<?=$row->address?>">
			</div>
			<div class="form-group">
				<label for="phone_num">Phone Number:</label>
				<input type="text" class="form-control" id="phone_num" name="phone_num" value="<?=$row->phone_num?>">
			</div>
			<button type="submit" class="btn btn-primary">Submit</button>
		</form>
		<?php
			    }
			}
		?>
	</div>