
	<div class="container">
		<h1>Mata Kuliah | Tambah Data Baru</h1>
		<form action="?page=mk_add_save" method="POST">
			<div class="form-group">
				<label for="kode_mk">Kode Mata Kuliah:</label>
				<input type="text" class="form-control" id="kode_mk" name="kode_mk" required>
			</div>
			<div class="form-group">
				<label for="nama">Nama:</label>
				<input type="text" class="form-control" id="nama" name="nama" required>
			</div>
			<div class="form-group">
				<label for="jml_sks">Jumlah SKS:</label>
				<input type="Number" class="form-control" id="jml_sks" name="jml_sks" required>
			</div>
			<button type="submit" class="btn btn-primary">Simpan</button>
		</form>
	</div>
