
	<div class="container">
		<h1>Daftar Mata Kuliah</h1>
		<table class="table table-striped">
			<thead>
				<tr>
					<th>Nomor</th>
					<th>Kode Mata Kuliah</th>
					<th>Nama</th>
					<th>Jumlah SKS</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					if (empty($qmk)) {
						echo "<tr>";
						echo "<td colspan='5'>-</td>";
						echo "</tr>";
					} else {
						$num = 0;
					    // output data of each row
						foreach ($qmk as $row) {
							# code...
					    	$num++;
					    	echo "<tr>";
					    	echo "<td>$num</td>";
					    	echo "<td>$row->kode_mk</td>";
					    	echo "<td>$row->nama</td>";
					    	echo "<td>$row->jml_sks</td>";
					    	echo "<td><a href='?page=mk_upd&id=$row->mk_id'>Edit</a> | <a href='?page=mk_del&id=$row->mk_id'>Delete</a></td>";
					    	echo "</tr>";
					    }
					} 
				?>
				
			</tbody>
		</table>
		<p><a href="?page=mk_add">Tambah Data</a></p>
	</div>
