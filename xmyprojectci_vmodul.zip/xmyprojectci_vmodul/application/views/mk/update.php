
	<div class="container">
		<h1>Mata Kuliah | Ubah Data Mata Kuliah</h1>
		<?php 
			if (empty($qmk)) {
				# code...

			} else {
				// output data of each row
				foreach ($qmk as $row) {
					# code...
		?>
		<form action="?page=mk_upd_save&id=<?=$row->mk_id?>" method="POST">
			<div class="form-group">
				<label for="kode_mk">Kode Mata Kuliah:</label>
				<input type="text" class="form-control" id="kode_mk" name="kode_mk" required value="<?=$row->kode_mk?>">
			</div>
			<div class="form-group">
				<label for="nama">Nama:</label>
				<input type="text" class="form-control" id="nama" name="nama" required value="<?=$row->nama?>">
			</div>
			<div class="form-group">
				<label for="jml_sks">Jumlah SKS:</label>
				<input type="Number" class="form-control" id="jml_sks" name="jml_sks" required value="<?=$row->jml_sks?>">
			</div>
			<button type="submit" class="btn btn-primary">Simpan</button>
		</form>
		<?php
			    }
			}
		?>
	</div>

		