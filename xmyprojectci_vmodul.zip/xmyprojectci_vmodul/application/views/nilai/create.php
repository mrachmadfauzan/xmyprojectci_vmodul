
	<div class="container">
		<h1>Nilai | Tambah Data Baru</h1>
		<form action="?page=nilai_add_save" method="POST">
			<div class="form-group">
				<label for="stu_id">Mahasiswa:</label>
				<select class="form-control" name="stu_id" id="stu_id">
					<?php 
						if (empty($qstudents)) {
							# code...
							echo "<option value='-'>-</option>";
						} else {
							// output data of each row
							foreach ($qstudents as $row_students) {
								# code...
								
									echo "<option value='".$row_students->stu_id."'>".$row_students->first_name." ".$row_students->last_name."</option>";
								
							}
						}
					?>
				</select>
			</div>
			<div class="form-group">
				<label for="mk_id">Mata Kuliah:</label>
				<select class="form-control" name="mk_id" id="mk_id">
					<?php 
						if (empty($qmk)) {
							# code...
							echo "<option value='-'>-</option>";
						} else {
							// output data of each row
							foreach ($qmk as $row_mk) {
								# code...
								
									echo "<option value='".$row_mk->mk_id."'>".$row_mk->nama."</option>";
								
							}
						}
					?>
				</select>
			</div>
			<div class="form-group">
				<label for="nilai">Nilai:</label>
				<input type="Number" class="form-control" id="nilai" name="nilai" required>
			</div>
			<button type="submit" class="btn btn-primary">Simpan</button>
		</form>
	</div>
