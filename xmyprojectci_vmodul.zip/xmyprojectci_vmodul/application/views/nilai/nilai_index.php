
	<div class="container">
		<h1>Daftar Nilai</h1>
		<table class="table table-striped">
			<thead>
				<tr>
					<th>Nomor</th>
					<th>Nama</th>
					<th>Mata Kuliah</th>
					<th>Nilai</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					if (empty($qnilai)) {
						echo "<tr>";
						echo "<td colspan='5'>-</td>";
						echo "</tr>";
					} else {
						$num = 0;
					    // output data of each row
						foreach ($qnilai as $row) {
							# code...
					    	$num++;
					    	echo "<tr>";
					    	echo "<td>$num</td>";
					    	echo "<td>$row->first_name $row->last_name</td>";
					    	echo "<td>$row->nama</td>";
					    	echo "<td>$row->nilai</td>";
					    	echo "<td><a href='?page=nilai_upd&id=$row->nilai_id'>Edit</a> | <a href='?page=nilai_del&id=$row->nilai_id'>Delete</a></td>";
					    	echo "</tr>";
					    }
					} 
				?>
				
			</tbody>
		</table>
		<p><a href="?page=nilai_add">Tambah Data</a></p>
	</div>
