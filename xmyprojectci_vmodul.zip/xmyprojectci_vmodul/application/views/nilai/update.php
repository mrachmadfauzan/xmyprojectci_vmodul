
	<div class="container">
		<h1>Nilai | Ubah Data Nilai</h1>
		<?php 
			if (empty($qnilai)) {
				# code...

			} else {
				// output data of each row
				foreach ($qnilai as $row) {
					# code...
		?>
		<form action="?page=nilai_upd_save&id=<?=$row->nilai_id?>" method="POST">
			<div class="form-group">
				<label for="stu_id">Mahasiswa:</label>
				<select class="form-control" name="stu_id" id="stu_id">
					<?php 
						if (empty($qstudents)) {
							# code...
							echo "<option value='-'>-</option>";
						} else {
							// output data of each row
							foreach ($qstudents as $row_students) {
								# code...
								if ($row->stu_id == $row_students->stu_id) {
									# code...
									echo "<option value='".$row_students->stu_id."' selected>".$row_students->first_name." ".$row_students->last_name."</option>";
								} else {
									echo "<option value='".$row_students->stu_id."'>".$row_students->first_name." ".$row_students->last_name."</option>";
								}
							}
						}
					?>
				</select>
			</div>
			<div class="form-group">
				<label for="mk_id">Mata Kuliah:</label>
				<select class="form-control" name="mk_id" id="mk_id">
					<?php 
						if (empty($qmk)) {
							# code...
							echo "<option value='-'>-</option>";
						} else {
							// output data of each row
							foreach ($qmk as $row_mk) {
								# code...
								if ($row->mk_id == $row_mk->mk_id) {
									# code...
									echo "<option value='".$row_mk->mk_id."' selected>".$row_mk->nama."</option>";
								} else {
									echo "<option value='".$row_mk->mk_id."'>".$row_mk->nama."</option>";
								}
							}
						}
					?>
				</select>
			</div>
			<div class="form-group">
				<label for="nilai">Nilai:</label>
				<input type="Number" class="form-control" id="nilai" name="nilai" required value="<?=$row->nilai?>">
			</div>
			<button type="submit" class="btn btn-primary">Simpan</button>
		</form>
		<?php
			    }
			}
		?>
	</div>

		